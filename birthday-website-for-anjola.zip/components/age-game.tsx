"use client"

import { useState, useCallback, useRef, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import confetti from "canvas-confetti"
import { Sparkles, Star, Heart } from "lucide-react"

interface AgeGameProps {
  onComplete: () => void
}

interface AgeCardProps {
  age: number
  isCorrect: boolean
  onClick: () => void
  cursorPosition: { x: number; y: number }
  index: number
}

function AgeCard({ age, isCorrect, onClick, cursorPosition, index }: AgeCardProps) {
  const cardRef = useRef<HTMLButtonElement>(null)
  const [position, setPosition] = useState({ x: 0, y: 0 })
  const [isNearby, setIsNearby] = useState(false)

  useEffect(() => {
    if (isCorrect || !cardRef.current) return

    const card = cardRef.current
    const rect = card.getBoundingClientRect()
    const cardCenterX = rect.left + rect.width / 2
    const cardCenterY = rect.top + rect.height / 2

    const distance = Math.sqrt(
      Math.pow(cursorPosition.x - cardCenterX, 2) +
      Math.pow(cursorPosition.y - cardCenterY, 2)
    )

    const escapeThreshold = 120
    const padding = 60 // Keep cards this far from edges

    if (distance < escapeThreshold && distance > 0) {
      setIsNearby(true)
      
      const angle = Math.atan2(cardCenterY - cursorPosition.y, cardCenterX - cursorPosition.x)
      const escapeDistance = Math.max(50, (escapeThreshold - distance) * 0.8)
      
      let newX = position.x + Math.cos(angle) * escapeDistance
      let newY = position.y + Math.sin(angle) * escapeDistance

      // Calculate boundaries relative to original position (position.x/y is already offset)
      // rect gives current position, so we need to account for existing offset
      const originalLeft = rect.left - position.x
      const originalTop = rect.top - position.y
      
      const minX = padding - originalLeft
      const maxX = window.innerWidth - rect.width - padding - originalLeft
      const minY = padding - originalTop
      const maxY = window.innerHeight - rect.height - padding - originalTop

      // Clamp to boundaries
      newX = Math.max(minX, Math.min(maxX, newX))
      newY = Math.max(minY, Math.min(maxY, newY))

      // If we hit a boundary, try to escape in a different direction
      if (newX === minX || newX === maxX || newY === minY || newY === maxY) {
        // Try perpendicular directions
        const perpAngle = angle + Math.PI / 2
        const altX = position.x + Math.cos(perpAngle) * escapeDistance * 0.5
        const altY = position.y + Math.sin(perpAngle) * escapeDistance * 0.5
        
        const clampedAltX = Math.max(minX, Math.min(maxX, altX))
        const clampedAltY = Math.max(minY, Math.min(maxY, altY))
        
        // Use alternative if it's different from current
        if (Math.abs(clampedAltX - position.x) > 5 || Math.abs(clampedAltY - position.y) > 5) {
          newX = clampedAltX
          newY = clampedAltY
        }
      }

      setPosition({ x: newX, y: newY })
    } else {
      setIsNearby(false)
    }
  }, [cursorPosition, isCorrect, position.x, position.y])

  return (
    <motion.button
      ref={cardRef}
      onClick={onClick}
      initial={{ opacity: 0, y: 40, rotateX: -15 }}
      animate={{
        opacity: 1,
        y: 0,
        rotateX: 0,
        x: position.x,
        y: position.y,
        scale: isNearby && !isCorrect ? 0.95 : 1,
        rotate: isNearby && !isCorrect ? (index % 2 === 0 ? -5 : 5) : 0,
      }}
      transition={{
        type: "spring",
        stiffness: 200,
        damping: 20,
        delay: index * 0.1,
      }}
      whileHover={isCorrect ? { scale: 1.05, y: -8 } : undefined}
      whileTap={isCorrect ? { scale: 0.98 } : undefined}
      className={`
        relative group w-24 h-32 md:w-32 md:h-40 rounded-2xl cursor-pointer
        bg-white border border-[var(--border)]
        shadow-[0_4px_24px_rgba(0,0,0,0.06),0_1px_2px_rgba(0,0,0,0.04)]
        hover:shadow-[0_12px_40px_rgba(139,92,246,0.15),0_4px_8px_rgba(0,0,0,0.05)]
        transition-all duration-300
        flex flex-col items-center justify-center
        overflow-hidden
      `}
    >
      {/* Background gradient on hover */}
      <div className="absolute inset-0 bg-gradient-to-br from-[var(--purple-light)]/0 via-transparent to-[var(--purple-light)]/0 group-hover:from-[var(--purple-light)]/10 group-hover:to-[var(--purple-soft)]/5 transition-all duration-300" />
      
      {/* Decorative top accent */}
      <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-[var(--purple-light)] via-[var(--purple-soft)] to-[var(--purple-light)] opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
      
      {/* Age number */}
      <span className="relative text-4xl md:text-5xl font-[var(--font-syne)] font-bold text-[var(--charcoal)] group-hover:text-[var(--purple-rich)] transition-colors duration-300">
        {age}
      </span>
      
      {/* Subtitle */}
      <span className="relative text-[10px] text-[var(--muted-foreground)] tracking-[0.2em] uppercase mt-2 font-[var(--font-outfit)]">
        years
      </span>

      {/* Decorative corners */}
      <div className="absolute bottom-2 right-2 w-2 h-2 rounded-full bg-[var(--purple-light)] group-hover:bg-[var(--purple-soft)] transition-colors opacity-0 group-hover:opacity-100" />
      <div className="absolute bottom-2 left-2 w-1 h-1 rounded-full bg-[var(--gold)] opacity-0 group-hover:opacity-100 transition-opacity" />
    </motion.button>
  )
}

export function AgeGame({ onComplete }: AgeGameProps) {
  const [cursorPosition, setCursorPosition] = useState({ x: 0, y: 0 })
  const [showSuccess, setShowSuccess] = useState(false)
  const [hasInteracted, setHasInteracted] = useState(false)

  const handleMouseMove = useCallback((e: React.MouseEvent | React.TouchEvent) => {
    if (!hasInteracted) setHasInteracted(true)
    const pos = 'touches' in e 
      ? { x: e.touches[0].clientX, y: e.touches[0].clientY }
      : { x: (e as React.MouseEvent).clientX, y: (e as React.MouseEvent).clientY }
    setCursorPosition(pos)
  }, [hasInteracted])

  const handleCorrectAnswer = useCallback(() => {
    setShowSuccess(true)
    
    const duration = 2500
    const end = Date.now() + duration
    const colors = ['#8b5cf6', '#a78bfa', '#c4b5fd', '#ddd6fe', '#fbbf24', '#fef3c7']

    const frame = () => {
      confetti({
        particleCount: 3,
        angle: 60,
        spread: 55,
        origin: { x: 0, y: 0.7 },
        colors: colors,
        gravity: 0.8,
      })
      confetti({
        particleCount: 3,
        angle: 120,
        spread: 55,
        origin: { x: 1, y: 0.7 },
        colors: colors,
        gravity: 0.8,
      })

      if (Date.now() < end) {
        requestAnimationFrame(frame)
      }
    }

    confetti({
      particleCount: 100,
      spread: 80,
      origin: { y: 0.6 },
      colors: colors,
    })

    frame()

    setTimeout(() => {
      onComplete()
    }, 2200)
  }, [onComplete])

  const handleWrongAnswer = useCallback(() => {
    // Card runs away - handled by the card itself
  }, [])

  const ages = [16, 17, 18, 19, 20]

  return (
    <div 
      className="min-h-screen flex flex-col items-center justify-center relative overflow-hidden"
      onMouseMove={handleMouseMove}
      onTouchMove={handleMouseMove}
    >
      {/* Elegant cream background */}
      <div className="absolute inset-0 bg-gradient-to-br from-[var(--cream)] via-white to-[var(--cream)]" />
      
      {/* Decorative floating elements */}
      <motion.div 
        animate={{ 
          y: [0, -25, 0],
          x: [0, 10, 0],
          opacity: [0.3, 0.5, 0.3],
        }}
        transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
        className="absolute top-16 right-16 w-72 h-72 rounded-full bg-[var(--purple-light)]/20 blur-3xl" 
      />
      <motion.div 
        animate={{ 
          y: [0, 20, 0],
          x: [0, -15, 0],
          opacity: [0.2, 0.4, 0.2],
        }}
        transition={{ duration: 12, repeat: Infinity, ease: "easeInOut", delay: 3 }}
        className="absolute bottom-24 left-16 w-80 h-80 rounded-full bg-[var(--gold-soft)]/20 blur-3xl" 
      />
      <motion.div 
        animate={{ 
          y: [-10, 15, -10],
          opacity: [0.15, 0.3, 0.15],
        }}
        transition={{ duration: 8, repeat: Infinity, ease: "easeInOut", delay: 1 }}
        className="absolute top-1/2 left-1/3 w-48 h-48 rounded-full bg-[var(--purple-soft)]/10 blur-3xl" 
      />

      {/* Floating icons */}
      <motion.div
        animate={{ y: [-5, 5, -5], rotate: [0, 10, 0] }}
        transition={{ duration: 4, repeat: Infinity }}
        className="absolute top-24 left-24 text-[var(--purple-light)]"
      >
        <Star className="w-5 h-5 fill-current opacity-40" />
      </motion.div>
      <motion.div
        animate={{ y: [5, -5, 5], rotate: [0, -10, 0] }}
        transition={{ duration: 5, repeat: Infinity, delay: 1 }}
        className="absolute bottom-32 right-32 text-[var(--gold)]"
      >
        <Sparkles className="w-6 h-6 opacity-50" />
      </motion.div>
      <motion.div
        animate={{ scale: [1, 1.1, 1] }}
        transition={{ duration: 3, repeat: Infinity, delay: 0.5 }}
        className="absolute top-1/3 right-24 text-[var(--purple-soft)]"
      >
        <Heart className="w-4 h-4 fill-current opacity-30" />
      </motion.div>

      {/* Grid pattern overlay */}
      <div className="absolute inset-0 opacity-[0.015]" style={{
        backgroundImage: `linear-gradient(var(--charcoal) 1px, transparent 1px), linear-gradient(90deg, var(--charcoal) 1px, transparent 1px)`,
        backgroundSize: '60px 60px'
      }} />

      <AnimatePresence mode="wait">
        {!showSuccess ? (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0, y: -30 }}
            transition={{ duration: 0.6 }}
            className="relative z-10 flex flex-col items-center px-6"
          >
            {/* Header */}
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="text-center mb-16"
            >
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.3 }}
                className="flex items-center justify-center gap-3 mb-6"
              >
                <div className="w-10 h-px bg-[var(--border)]" />
                <span className="text-xs tracking-[0.25em] uppercase text-[var(--muted-foreground)] font-[var(--font-outfit)]">
                  A birthday question
                </span>
                <div className="w-10 h-px bg-[var(--border)]" />
              </motion.div>
              
              <motion.h1
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
                className="text-3xl sm:text-4xl md:text-6xl lg:text-7xl text-[var(--charcoal)] font-[var(--font-syne)] font-bold leading-tight"
              >
                How old is
              </motion.h1>
              
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6 }}
                className="mt-2"
              >
                <span className="text-3xl sm:text-4xl md:text-6xl lg:text-7xl font-[var(--font-libre)] italic text-[var(--purple-rich)]">
                  Anjola
                </span>
                <span className="text-3xl sm:text-4xl md:text-6xl lg:text-7xl text-[var(--charcoal)] font-[var(--font-syne)] font-bold">?</span>
              </motion.div>
              
              <motion.div
                initial={{ scaleX: 0 }}
                animate={{ scaleX: 1 }}
                transition={{ delay: 0.9, duration: 0.8 }}
                className="mt-8 h-px w-40 mx-auto bg-gradient-to-r from-transparent via-[var(--purple-soft)] to-transparent"
              />
            </motion.div>

            {/* Age cards */}
            <div className="flex flex-wrap justify-center gap-4 md:gap-6 max-w-xl">
              {ages.map((age, index) => (
                <AgeCard
                  key={age}
                  age={age}
                  isCorrect={age === 19}
                  onClick={age === 19 ? handleCorrectAnswer : handleWrongAnswer}
                  cursorPosition={cursorPosition}
                  index={index}
                />
              ))}
            </div>

            {/* Hint */}
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: hasInteracted ? 0.7 : 0 }}
              transition={{ delay: 0.5 }}
              className="mt-14 text-sm text-[var(--muted-foreground)] italic font-[var(--font-libre)]"
            >
              psst... some answers are shy
            </motion.p>
          </motion.div>
        ) : (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
            className="relative z-10 text-center px-6"
          >
            <motion.div
              initial={{ scale: 0.5, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ type: "spring", stiffness: 200, damping: 12 }}
              className="mb-6"
            >
              <span className="text-9xl md:text-[10rem] font-[var(--font-syne)] font-extrabold text-[var(--purple-rich)]">
                19
              </span>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="flex items-center justify-center gap-4"
            >
              <div className="w-8 h-px bg-[var(--gold)]" />
              <p className="text-xl md:text-2xl text-[var(--charcoal-light)] font-[var(--font-libre)] italic">
                You got it
              </p>
              <div className="w-8 h-px bg-[var(--gold)]" />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Corner decorations - hidden on mobile */}
      <div className="hidden sm:block absolute top-6 left-6 w-12 h-12 border-l-2 border-t-2 border-[var(--border)] opacity-20" />
      <div className="hidden sm:block absolute top-6 right-6 w-12 h-12 border-r-2 border-t-2 border-[var(--border)] opacity-20" />
      <div className="hidden sm:block absolute bottom-6 left-6 w-12 h-12 border-l-2 border-b-2 border-[var(--border)] opacity-20" />
      <div className="hidden sm:block absolute bottom-6 right-6 w-12 h-12 border-r-2 border-b-2 border-[var(--border)] opacity-20" />

      {/* Footer accent */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex items-center gap-4"
      >
        <div className="w-6 h-px bg-[var(--border)]" />
        <div className="w-2 h-2 rounded-full bg-[var(--purple-soft)]" />
        <div className="w-6 h-px bg-[var(--border)]" />
      </motion.div>
    </div>
  )
}
