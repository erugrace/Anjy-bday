"use client"

import { motion } from "framer-motion"
import Image from "next/image"
import { useState } from "react"

interface MessageCard {
  id: number
  name: string
  avatar: string
  message: string
}

// Placeholder messages - replace with actual messages from friends
const messages: MessageCard[] = [
  {
    id: 1,
    name: "Friend Name 1",
    avatar: "/avatars/person-1.jpg",
    message: "Add your birthday message here. This can be as long as needed - multiple paragraphs, heartfelt words, memories shared together, wishes for the future, and everything in between. The card will expand to fit the content.",
  },
  {
    id: 2,
    name: "Friend Name 2",
    avatar: "/avatars/person-2.jpg",
    message: "Another heartfelt message goes here. Feel free to write as much as you want - share memories, inside jokes, hopes and dreams for the birthday girl. Every word matters.",
  },
  {
    id: 3,
    name: "Friend Name 3",
    avatar: "/avatars/person-3.jpg",
    message: "Your message here. The design adapts to any length, so whether it's a quick birthday wish or a long letter filled with love and appreciation, it will look beautiful.",
  },
  {
    id: 4,
    name: "Friend Name 4",
    avatar: "/avatars/person-4.jpg",
    message: "Write your birthday wishes here. Share what makes Anjola special to you, your favorite memories together, and what you wish for her in this new year of life.",
  },
  {
    id: 5,
    name: "Friend Name 5",
    avatar: "/avatars/person-5.jpg",
    message: "Your personal message to Anjola. This space is for you to express your love, appreciation, and birthday wishes in your own words.",
  },
  {
    id: 6,
    name: "Friend Name 6",
    avatar: "/avatars/person-6.jpg",
    message: "A message from the heart. Tell her how much she means to you, share your favorite moments, and wish her well on this special day.",
  },
  {
    id: 7,
    name: "Friend Name 7",
    avatar: "/avatars/person-7.jpg",
    message: "Birthday wishes go here. Whether short and sweet or long and detailed, every message adds to the celebration of her special day.",
  },
  {
    id: 8,
    name: "Friend Name 8",
    avatar: "/avatars/person-8.jpg",
    message: "Your heartfelt words here. Let Anjola know how special she is and how grateful you are to have her in your life.",
  },
  {
    id: 9,
    name: "Friend Name 9",
    avatar: "/avatars/person-9.jpg",
    message: "Add your birthday message. Share your love, your memories, your hopes for her future - this is your space to celebrate her.",
  },
  {
    id: 10,
    name: "Friend Name 10",
    avatar: "/avatars/person-10.jpg",
    message: "Your message to the birthday girl. Make it personal, make it meaningful, make it yours.",
  },
]

function MessageItem({ card, index }: { card: MessageCard; index: number }) {
  const [imgError, setImgError] = useState(false)
  const isEven = index % 2 === 0

  return (
    <motion.div
      initial={{ opacity: 0, x: isEven ? -30 : 30 }}
      whileInView={{ opacity: 1, x: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ delay: index * 0.08, duration: 0.5 }}
      className={`flex items-start gap-4 md:gap-6 ${isEven ? '' : 'flex-row-reverse'}`}
    >
      {/* Avatar with name */}
      <motion.div 
        className="shrink-0 text-center"
        whileHover={{ scale: 1.05 }}
      >
        <div className="relative mb-2">
          <div className="w-14 h-14 md:w-16 md:h-16 rounded-full overflow-hidden ring-2 ring-[var(--purple-light)]/50 ring-offset-2 ring-offset-[var(--cream)]">
            {!imgError ? (
              <Image
                src={card.avatar}
                alt={card.name}
                width={64}
                height={64}
                className="object-cover w-full h-full"
                onError={() => setImgError(true)}
              />
            ) : (
              <div className="w-full h-full bg-gradient-to-br from-[var(--purple-light)] to-[var(--purple-soft)] flex items-center justify-center">
                <span className="text-lg text-white font-[var(--font-syne)] font-bold">
                  {card.name.charAt(0)}
                </span>
              </div>
            )}
          </div>
          {/* Accent dot */}
          <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-[var(--purple-soft)] rounded-full border-2 border-[var(--cream)]" />
        </div>
        <p className="text-xs font-[var(--font-syne)] font-semibold text-[var(--charcoal)] max-w-[80px] truncate">
          {card.name}
        </p>
      </motion.div>

      {/* Message bubble */}
      <motion.div
        whileHover={{ y: -2 }}
        className={`flex-1 relative bg-white rounded-2xl p-5 md:p-6 shadow-sm border border-[var(--border)] 
                   ${isEven ? 'rounded-tl-sm' : 'rounded-tr-sm'}`}
      >
        {/* Speech bubble pointer */}
        <div 
          className={`absolute top-4 w-3 h-3 bg-white border-[var(--border)] rotate-45
                     ${isEven ? '-left-1.5 border-l border-b' : '-right-1.5 border-r border-t'}`}
        />
        
        {/* Message content */}
        <p className="text-[var(--charcoal)] leading-relaxed font-[var(--font-outfit)] text-sm md:text-base whitespace-pre-wrap">
          {card.message}
        </p>
        
        {/* Decorative corner */}
        <div className={`absolute bottom-3 ${isEven ? 'right-3' : 'left-3'} flex gap-1`}>
          <div className="w-1 h-1 rounded-full bg-[var(--purple-light)]" />
          <div className="w-1 h-1 rounded-full bg-[var(--purple-soft)]" />
          <div className="w-1 h-1 rounded-full bg-[var(--purple-rich)]" />
        </div>
      </motion.div>
    </motion.div>
  )
}

export function MessageCards() {
  return (
    <section className="py-20 md:py-32 px-4 relative overflow-hidden grain-overlay">
      {/* Cream background */}
      <div className="absolute inset-0 bg-[var(--cream)]" />
      
      {/* Subtle accents */}
      <motion.div 
        animate={{ opacity: [0.15, 0.25, 0.15] }}
        transition={{ duration: 10, repeat: Infinity }}
        className="absolute top-1/4 left-0 w-64 h-64 bg-[var(--purple-light)]/30 rounded-full blur-3xl" 
      />
      <motion.div 
        animate={{ opacity: [0.1, 0.2, 0.1] }}
        transition={{ duration: 12, repeat: Infinity, delay: 3 }}
        className="absolute bottom-1/4 right-0 w-80 h-80 bg-[var(--gold-soft)]/20 rounded-full blur-3xl" 
      />

      <div className="max-w-2xl mx-auto relative z-10">
        {/* Section title */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <span className="text-xs tracking-[0.3em] uppercase text-[var(--muted-foreground)] mb-4 block font-[var(--font-outfit)]">
            From loved ones
          </span>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-[var(--font-syne)] font-bold text-[var(--charcoal)] mb-4">
            Birthday Wishes
          </h2>
          <div className="w-24 h-px bg-gradient-to-r from-transparent via-[var(--purple-soft)] to-transparent mx-auto mb-6" />
          <p className="text-[var(--charcoal-light)] text-lg max-w-md mx-auto font-[var(--font-libre)] italic">
            Messages from the people who love you most
          </p>
        </motion.div>

        {/* Message cards */}
        <div className="space-y-6">
          {messages.map((card, index) => (
            <MessageItem key={card.id} card={card} index={index} />
          ))}
        </div>

        {/* End decoration */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.3 }}
          className="flex items-center justify-center gap-3 mt-12"
        >
          <span className="w-12 h-px bg-[var(--border)]" />
          <div className="w-2 h-2 rounded-full bg-[var(--purple-soft)]" />
          <span className="w-12 h-px bg-[var(--border)]" />
        </motion.div>
      </div>
    </section>
  )
}
