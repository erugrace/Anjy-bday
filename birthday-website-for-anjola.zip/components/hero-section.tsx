"use client"

import { motion } from "framer-motion"
import { ChevronDown, Sparkles } from "lucide-react"
import { Countdown } from "./countdown"

export function HeroSection() {
  return (
    <section className="min-h-screen flex flex-col items-center justify-center relative overflow-hidden grain-overlay">
      {/* Warm neutral background */}
      <div className="absolute inset-0 bg-[var(--cream)]" />
      
      {/* Subtle gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-white/30 via-transparent to-[var(--purple-light)]/5" />
      
      {/* Decorative accents */}
      <motion.div 
        animate={{ 
          opacity: [0.3, 0.5, 0.3],
          scale: [1, 1.05, 1],
        }}
        transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
        className="absolute top-1/4 right-1/4 w-96 h-96 bg-[var(--purple-light)]/15 rounded-full blur-3xl" 
      />
      <motion.div 
        animate={{ 
          opacity: [0.2, 0.4, 0.2],
        }}
        transition={{ duration: 12, repeat: Infinity, ease: "easeInOut", delay: 3 }}
        className="absolute bottom-1/4 left-1/4 w-80 h-80 bg-[var(--gold-soft)]/10 rounded-full blur-3xl" 
      />

      {/* Main content */}
      <div className="relative z-10 text-center px-6 max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
        >
          {/* Top decoration */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="flex items-center justify-center gap-4 mb-8"
          >
            <div className="w-12 h-px bg-[var(--border)]" />
            <Sparkles className="w-4 h-4 text-[var(--purple-soft)]" />
            <span className="text-xs tracking-[0.3em] uppercase text-[var(--muted-foreground)] font-[var(--font-outfit)]">
              Celebrating
            </span>
            <Sparkles className="w-4 h-4 text-[var(--purple-soft)]" />
            <div className="w-12 h-px bg-[var(--border)]" />
          </motion.div>
          
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7, duration: 0.8 }}
            className="text-3xl sm:text-5xl md:text-7xl lg:text-8xl font-[var(--font-syne)] font-bold text-[var(--charcoal)] mb-2 leading-[1.1]"
          >
            Anjolaoluwa
          </motion.h1>
          
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.9, duration: 0.6 }}
            className="flex items-center justify-center gap-4 mb-6"
          >
            <div className="w-16 h-px bg-gradient-to-r from-transparent via-[var(--purple-soft)] to-transparent" />
            <span className="text-4xl sm:text-6xl md:text-8xl lg:text-9xl font-[var(--font-syne)] font-extrabold text-gradient-purple">
              19
            </span>
            <div className="w-16 h-px bg-gradient-to-r from-transparent via-[var(--purple-soft)] to-transparent" />
          </motion.div>
          
          <motion.p
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.2 }}
            className="text-lg md:text-xl text-[var(--charcoal-light)] font-[var(--font-libre)] italic max-w-md mx-auto mb-8"
          >
            A little corner of the internet, made with love
          </motion.p>

          {/* Countdown */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.4 }}
          >
            <Countdown />
          </motion.div>
        </motion.div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2 }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2"
      >
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
          className="flex flex-col items-center text-[var(--muted-foreground)]"
        >
          <span className="text-xs mb-3 tracking-widest uppercase font-[var(--font-outfit)]">Explore</span>
          <ChevronDown className="w-5 h-5" />
        </motion.div>
      </motion.div>

      {/* Corner decorations - hidden on mobile */}
      <div className="hidden sm:block absolute top-8 left-8 w-16 h-16 border-l border-t border-[var(--border)] opacity-30" />
      <div className="hidden sm:block absolute top-8 right-8 w-16 h-16 border-r border-t border-[var(--border)] opacity-30" />
      <div className="hidden sm:block absolute bottom-8 left-8 w-16 h-16 border-l border-b border-[var(--border)] opacity-30" />
      <div className="hidden sm:block absolute bottom-8 right-8 w-16 h-16 border-r border-b border-[var(--border)] opacity-30" />
    </section>
  )
}
