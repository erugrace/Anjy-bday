"use client"

import { motion } from "framer-motion"
import Image from "next/image"
import { Download } from "lucide-react"
import { useState } from "react"

interface Book {
  id: number
  title: string
  author: string
  cover: string
  pdfUrl: string
}

const books: Book[] = [
  {
    id: 1,
    title: "Purple Hibiscus",
    author: "Chimamanda Ngozi Adichie",
    cover: "/books/book-1.jpg",
    pdfUrl: "/pdfs/book-1.pdf",
  },
  {
    id: 2,
    title: "Things Fall Apart",
    author: "Chinua Achebe",
    cover: "/books/book-2.jpg",
    pdfUrl: "/pdfs/book-2.pdf",
  },
  {
    id: 3,
    title: "The Lion and the Jewel",
    author: "Wole Soyinka",
    cover: "/books/book-3.jpg",
    pdfUrl: "/pdfs/book-3.pdf",
  },
  {
    id: 4,
    title: "The Secret Lives of Baba Segi's Wives",
    author: "Lola Shoneyin",
    cover: "/books/book-4.jpg",
    pdfUrl: "/pdfs/book-4.pdf",
  },
  {
    id: 5,
    title: "Children of Blood and Bone",
    author: "Tomi Adeyemi",
    cover: "/books/book-5.jpg",
    pdfUrl: "/pdfs/book-5.pdf",
  },
]

function BookCard({ book, index }: { book: Book; index: number }) {
  const [imgError, setImgError] = useState(false)

  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ delay: index * 0.12, duration: 0.6 }}
      whileHover={{ 
        y: -8,
        transition: { duration: 0.3 }
      }}
      className="group"
    >
      <div className="relative">
        {/* Book cover */}
        <div className="relative aspect-[2/3] rounded-lg overflow-hidden shadow-[0_8px_30px_rgba(0,0,0,0.12)]
                        bg-gradient-to-br from-[var(--cream)] to-[var(--purple-light)]/20
                        group-hover:shadow-[0_12px_40px_rgba(139,92,246,0.15)] transition-all duration-300">
          {!imgError ? (
            <Image
              src={book.cover}
              alt={book.title}
              fill
              className="object-cover"
              onError={() => setImgError(true)}
            />
          ) : (
            <div className="w-full h-full flex flex-col items-center justify-center p-4 text-center border border-[var(--border)]">
              <div className="w-10 h-px bg-[var(--purple-soft)] mb-4" />
              <h4 className="text-[var(--charcoal)] font-[var(--font-syne)] font-semibold text-sm leading-tight mb-2">
                {book.title}
              </h4>
              <p className="text-[var(--muted-foreground)] text-xs font-[var(--font-outfit)]">
                {book.author}
              </p>
              <div className="w-10 h-px bg-[var(--purple-soft)] mt-4" />
            </div>
          )}
          
          {/* Hover overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-[var(--charcoal)]/90 via-[var(--charcoal)]/30 to-transparent 
                          opacity-0 group-hover:opacity-100 transition-opacity duration-300
                          flex flex-col justify-end p-4">
            <motion.a
              href={book.pdfUrl}
              download
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="flex items-center justify-center gap-2 w-full py-2.5 rounded-lg
                         bg-white hover:bg-[var(--purple-light)] text-[var(--charcoal)] 
                         font-[var(--font-space)] text-sm font-medium
                         transition-colors"
              onClick={(e) => e.stopPropagation()}
            >
              <Download className="w-4 h-4" />
              Download
            </motion.a>
          </div>

          {/* Book spine effect */}
          <div className="absolute left-0 top-0 bottom-0 w-1.5 bg-gradient-to-r from-black/15 to-transparent" />
        </div>
      </div>

      {/* Book info */}
      <div className="mt-4 text-center">
        <h4 className="text-[var(--charcoal)] font-[var(--font-syne)] font-semibold text-sm leading-tight mb-1 
                       group-hover:text-[var(--purple-rich)] transition-colors">
          {book.title}
        </h4>
        <p className="text-[var(--muted-foreground)] text-xs font-[var(--font-outfit)]">
          {book.author}
        </p>
      </div>
    </motion.div>
  )
}

export function BookGifts() {
  return (
    <section className="py-20 md:py-32 px-4 relative overflow-hidden grain-overlay">
      {/* Slightly darker cream background */}
      <div className="absolute inset-0 bg-[var(--cream-dark)]" />
      
      {/* Decorative elements */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[var(--border)] to-transparent" />
      <motion.div 
        animate={{ opacity: [0.15, 0.25, 0.15] }}
        transition={{ duration: 10, repeat: Infinity }}
        className="absolute top-1/4 right-1/4 w-64 h-64 bg-[var(--purple-light)]/20 rounded-full blur-3xl" 
      />

      <div className="max-w-5xl mx-auto relative z-10">
        {/* Section title */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <span className="text-xs tracking-[0.3em] uppercase text-[var(--muted-foreground)] mb-4 block font-[var(--font-outfit)]">
            A special gift
          </span>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-[var(--font-syne)] font-bold text-[var(--charcoal)] mb-2">
            For Your <span className="text-gradient-purple">19th</span>
          </h2>
          <div className="w-24 h-px bg-gradient-to-r from-transparent via-[var(--purple-soft)] to-transparent mx-auto my-6" />
          <p className="text-[var(--charcoal-light)] text-lg max-w-lg mx-auto font-[var(--font-libre)] italic">
            A curated collection of books by incredible Nigerian authors
          </p>
        </motion.div>

        {/* Bookshelf */}
        <div className="relative">
          {/* Books grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-5 md:gap-6">
            {books.map((book, index) => (
              <BookCard key={book.id} book={book} index={index} />
            ))}
          </div>

          {/* Shelf line */}
          <motion.div
            initial={{ scaleX: 0 }}
            whileInView={{ scaleX: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.8, duration: 0.8 }}
            className="mt-10 h-px bg-gradient-to-r from-transparent via-[var(--purple-soft)] to-transparent origin-left"
          />
        </div>

        {/* Note */}
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 1 }}
          className="text-center text-[var(--muted-foreground)] mt-8 text-sm italic font-[var(--font-libre)]"
        >
          Hover over each book to download
        </motion.p>
      </div>
    </section>
  )
}
