"use client"

import { motion } from "framer-motion"
import Image from "next/image"
import { useState } from "react"
import { ChevronLeft, ChevronRight, Heart, Star, Sparkles } from "lucide-react"

interface Photo {
  id: number
  src: string
  alt: string
  rotation: number
  tag?: string
  isOld?: boolean
}

const oldPhotos: Photo[] = [
  { id: 1, src: "/photos/old-1.jpg", alt: "Childhood memory 1", rotation: -3, tag: "Baby Anjola", isOld: true },
  { id: 2, src: "/photos/old-2.jpg", alt: "Childhood memory 2", rotation: 4, tag: "Growing up", isOld: true },
  { id: 3, src: "/photos/old-3.jpg", alt: "Childhood memory 3", rotation: -2, tag: "The early days", isOld: true },
]

const recentPhotos: Photo[] = [
  { id: 4, src: "/photos/recent-1.jpg", alt: "Recent memory 1", rotation: 2, tag: "Queen things" },
  { id: 5, src: "/photos/recent-2.jpg", alt: "Recent memory 2", rotation: -4, tag: "Main character" },
  { id: 6, src: "/photos/recent-3.jpg", alt: "Recent memory 3", rotation: 3, tag: "Slaying always" },
  { id: 7, src: "/photos/recent-4.jpg", alt: "Recent memory 4", rotation: -2, tag: "Living life" },
  { id: 8, src: "/photos/recent-5.jpg", alt: "Recent memory 5", rotation: 5, tag: "Beautiful soul" },
  { id: 9, src: "/photos/recent-6.jpg", alt: "Recent memory 6", rotation: -3, tag: "That smile" },
]

function PhotoCard({ photo, index }: { photo: Photo; index: number }) {
  const [isHovered, setIsHovered] = useState(false)
  const [imgError, setImgError] = useState(false)

  return (
    <motion.div
      initial={{ opacity: 0, y: 50, rotate: photo.rotation }}
      whileInView={{ opacity: 1, y: 0, rotate: photo.rotation }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ delay: index * 0.1, duration: 0.6 }}
      whileHover={{ 
        scale: 1.05, 
        rotate: 0,
        zIndex: 20,
        transition: { duration: 0.3 }
      }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className="relative group cursor-pointer"
      style={{ transform: `rotate(${photo.rotation}deg)` }}
    >
      {/* Decorative tape */}
      <div className="absolute -top-3 left-1/2 -translate-x-1/2 w-14 h-5 bg-[var(--gold-soft)]/70 rounded-sm z-10 
                      shadow-sm rotate-1" />
      
      {/* Tag label */}
      {photo.tag && (
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ delay: index * 0.1 + 0.3 }}
          className="absolute -top-1 -right-2 z-20"
        >
          <div className="bg-[var(--purple-rich)] text-white text-[10px] px-2 py-1 rounded-full font-[var(--font-outfit)] font-medium shadow-md -rotate-6">
            {photo.tag}
          </div>
        </motion.div>
      )}
      
      {/* Photo frame */}
      <div className="relative bg-white p-2 md:p-3 shadow-[0_4px_20px_rgba(0,0,0,0.08)] rounded-sm overflow-hidden">
        <div className="relative aspect-[4/5] w-full overflow-hidden bg-[var(--cream-dark)]">
          {!imgError ? (
            <Image
              src={photo.src}
              alt={photo.alt}
              fill
              className="object-cover transition-transform duration-500 group-hover:scale-105"
              onError={() => setImgError(true)}
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-[var(--cream)] to-[var(--purple-light)]/30">
              <div className="text-center text-[var(--charcoal-light)] p-4">
                <Sparkles className="w-8 h-8 mx-auto mb-2 text-[var(--purple-soft)]" />
                <p className="text-xs font-[var(--font-outfit)] tracking-wide">{photo.tag || 'Photo'}</p>
              </div>
            </div>
          )}
          
          {/* Hover overlay with heart */}
          <motion.div 
            animate={{ opacity: isHovered ? 1 : 0 }}
            className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent flex items-end justify-center pb-3"
          >
            <Heart className="w-5 h-5 text-white fill-white/80" />
          </motion.div>
        </div>
        
        {/* Photo caption area */}
        <div className="mt-2 h-5 flex items-center justify-center">
          <p className="text-[10px] text-[var(--muted-foreground)] italic font-[var(--font-libre)]">
            {photo.isOld ? 'Memories' : 'Recent'}
          </p>
        </div>
      </div>

      {/* Corner decorations */}
      <div className="absolute -bottom-1 -left-1 w-3 h-3 border-l-2 border-b-2 border-[var(--purple-light)] opacity-0 group-hover:opacity-100 transition-opacity" />
      <div className="absolute -bottom-1 -right-1 w-3 h-3 border-r-2 border-b-2 border-[var(--purple-light)] opacity-0 group-hover:opacity-100 transition-opacity" />
    </motion.div>
  )
}

function ArrowDecoration({ direction, className }: { direction: 'left' | 'right'; className?: string }) {
  const Icon = direction === 'left' ? ChevronLeft : ChevronRight
  
  return (
    <motion.div
      initial={{ opacity: 0, x: direction === 'left' ? -20 : 20 }}
      whileInView={{ opacity: 1, x: 0 }}
      viewport={{ once: true }}
      className={`hidden md:flex items-center gap-2 text-[var(--charcoal-light)] ${className}`}
    >
      {direction === 'right' && <span className="w-12 h-px bg-[var(--border)]" />}
      <motion.div
        animate={{ x: direction === 'left' ? [-3, 3, -3] : [3, -3, 3] }}
        transition={{ duration: 2, repeat: Infinity }}
      >
        <Icon className="w-5 h-5" />
      </motion.div>
      {direction === 'left' && <span className="w-12 h-px bg-[var(--border)]" />}
    </motion.div>
  )
}

export function PhotoGallery() {
  return (
    <section className="py-20 md:py-32 px-4 relative overflow-x-hidden grain-overlay">
      {/* Warm cream background */}
      <div className="absolute inset-0 bg-[var(--cream-dark)]" />
      
      {/* Subtle accents */}
      <motion.div 
        animate={{ opacity: [0.2, 0.35, 0.2] }}
        transition={{ duration: 8, repeat: Infinity }}
        className="absolute top-1/4 right-1/4 w-80 h-80 bg-[var(--purple-light)]/20 rounded-full blur-3xl" 
      />

      {/* Floating decorative elements */}
      <motion.div
        animate={{ y: [-10, 10, -10], rotate: [0, 10, 0] }}
        transition={{ duration: 6, repeat: Infinity }}
        className="absolute top-20 left-10 text-[var(--purple-soft)]"
      >
        <Star className="w-6 h-6 fill-current opacity-40" />
      </motion.div>
      <motion.div
        animate={{ y: [10, -10, 10], rotate: [0, -10, 0] }}
        transition={{ duration: 8, repeat: Infinity }}
        className="absolute bottom-32 right-16 text-[var(--gold)]"
      >
        <Sparkles className="w-8 h-8 opacity-50" />
      </motion.div>

      <div className="max-w-6xl mx-auto relative z-10">
        {/* Section title */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <span className="text-xs tracking-[0.3em] uppercase text-[var(--muted-foreground)] mb-4 block font-[var(--font-outfit)]">
            Through the years
          </span>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-[var(--font-syne)] font-bold text-[var(--charcoal)] mb-4">
            Memory Lane
          </h2>
          <div className="w-24 h-px bg-gradient-to-r from-transparent via-[var(--purple-soft)] to-transparent mx-auto mb-6" />
          <p className="text-[var(--charcoal-light)] text-lg max-w-md mx-auto font-[var(--font-libre)] italic">
            A scrapbook of beautiful moments
          </p>
        </motion.div>

        {/* Old photos section */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="mb-16"
        >
          <div className="flex items-center justify-between mb-8">
            <ArrowDecoration direction="left" />
            <motion.h3
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-lg text-[var(--charcoal)] font-[var(--font-syne)] font-semibold flex items-center gap-3"
            >
              <span className="w-8 h-px bg-[var(--purple-soft)]" />
              The Early Years
              <span className="text-[var(--purple-rich)] text-sm">(Throwbacks)</span>
              <span className="w-8 h-px bg-[var(--purple-soft)]" />
            </motion.h3>
            <ArrowDecoration direction="right" />
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 gap-6 md:gap-8 max-w-3xl mx-auto">
            {oldPhotos.map((photo, index) => (
              <PhotoCard key={photo.id} photo={photo} index={index} />
            ))}
          </div>
        </motion.div>

        {/* Connecting element with text */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="flex items-center justify-center gap-4 my-12"
        >
          <motion.div
            initial={{ scaleX: 0 }}
            whileInView={{ scaleX: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="w-20 h-px bg-gradient-to-r from-transparent to-[var(--purple-soft)] origin-left"
          />
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
            className="w-10 h-10 rounded-full border border-[var(--purple-soft)] flex items-center justify-center"
          >
            <Sparkles className="w-4 h-4 text-[var(--purple-soft)]" />
          </motion.div>
          <span className="text-sm text-[var(--charcoal-light)] font-[var(--font-outfit)] tracking-wide">
            Then & Now
          </span>
          <motion.div
            animate={{ rotate: -360 }}
            transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
            className="w-10 h-10 rounded-full border border-[var(--gold)] flex items-center justify-center"
          >
            <Heart className="w-4 h-4 text-[var(--gold)]" />
          </motion.div>
          <motion.div
            initial={{ scaleX: 0 }}
            whileInView={{ scaleX: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="w-20 h-px bg-gradient-to-l from-transparent to-[var(--gold)] origin-right"
          />
        </motion.div>

        {/* Recent photos section */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
        >
          <div className="flex items-center justify-between mb-8">
            <ArrowDecoration direction="left" />
            <motion.h3
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-lg text-[var(--charcoal)] font-[var(--font-syne)] font-semibold flex items-center gap-3"
            >
              <span className="w-8 h-px bg-[var(--gold)]" />
              Recent Memories
              <span className="text-[var(--purple-rich)] text-sm">(Slay era)</span>
              <span className="w-8 h-px bg-[var(--gold)]" />
            </motion.h3>
            <ArrowDecoration direction="right" />
          </div>
          
          {/* Masonry grid */}
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-6">
            {recentPhotos.map((photo, index) => (
              <div 
                key={photo.id}
                className={index === 1 || index === 4 ? 'md:mt-8' : index === 2 || index === 5 ? 'md:mt-16' : ''}
              >
                <PhotoCard photo={photo} index={index + 3} />
              </div>
            ))}
          </div>
        </motion.div>

        {/* Decorative notes - hidden on mobile */}
        <motion.div
          initial={{ opacity: 0, rotate: -8 }}
          whileInView={{ opacity: 1, rotate: -4 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5 }}
          className="absolute -bottom-4 right-4 md:right-20 w-36 md:w-44 p-4 bg-white shadow-lg rounded-sm hidden md:block"
        >
          <div className="w-full h-1 bg-[var(--purple-soft)]/30 rounded-full mb-2" />
          <p className="text-[var(--charcoal-light)] text-sm font-[var(--font-libre)] italic text-center">
            Every moment is a treasure
          </p>
          <Heart className="w-3 h-3 text-[var(--purple-soft)] mx-auto mt-2" />
        </motion.div>

        <motion.div
          initial={{ opacity: 0, rotate: 6 }}
          whileInView={{ opacity: 1, rotate: 3 }}
          viewport={{ once: true }}
          transition={{ delay: 0.6 }}
          className="absolute top-40 left-4 md:left-10 hidden lg:block w-32 p-3 bg-[var(--gold-soft)]/50 shadow-md rounded-sm"
        >
          <p className="text-[var(--charcoal)] text-xs font-[var(--font-outfit)] text-center">
            19 years of magic
          </p>
        </motion.div>
      </div>
    </section>
  )
}
