"use client"

import { motion } from "framer-motion"
import { useEffect, useState } from "react"

interface TimeLeft {
  days: number
  hours: number
  minutes: number
  seconds: number
}

export function Countdown() {
  const [timeLeft, setTimeLeft] = useState<TimeLeft | null>(null)
  const [isToday, setIsToday] = useState(false)
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
    
    const calculateTimeLeft = () => {
      const now = new Date()
      const currentYear = now.getFullYear()
      
      // Target: May 16th of current year (or next year if already passed)
      let targetDate = new Date(currentYear, 4, 16, 0, 0, 0) // Month is 0-indexed, so 4 = May
      
      // If May 16th has already passed this year, target next year
      if (now > targetDate) {
        targetDate = new Date(currentYear + 1, 4, 16, 0, 0, 0)
      }
      
      const difference = targetDate.getTime() - now.getTime()
      
      // Check if it's the day (May 16th)
      if (now.getMonth() === 4 && now.getDate() === 16) {
        setIsToday(true)
        return null
      }
      
      if (difference <= 0) {
        setIsToday(true)
        return null
      }
      
      return {
        days: Math.floor(difference / (1000 * 60 * 60 * 24)),
        hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
        minutes: Math.floor((difference / 1000 / 60) % 60),
        seconds: Math.floor((difference / 1000) % 60),
      }
    }

    setTimeLeft(calculateTimeLeft())
    
    const timer = setInterval(() => {
      setTimeLeft(calculateTimeLeft())
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  if (!mounted) {
    return (
      <div className="flex items-center justify-center py-8">
        <div className="w-6 h-6 border-2 border-[var(--purple-soft)] border-t-transparent rounded-full animate-spin" />
      </div>
    )
  }

  if (isToday) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        className="text-center py-8"
      >
        <motion.div
          animate={{ 
            scale: [1, 1.05, 1],
          }}
          transition={{ duration: 2, repeat: Infinity }}
          className="inline-block"
        >
          <span className="text-2xl sm:text-4xl md:text-6xl lg:text-7xl font-[var(--font-syne)] font-extrabold tracking-tight">
            <span className="text-[var(--purple-rich)]">{"It's"}</span>{" "}
            <span className="text-[var(--charcoal)]">D-Day!</span>
          </span>
        </motion.div>
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="mt-4 flex items-center justify-center gap-2"
        >
          <span className="w-8 h-px bg-[var(--purple-soft)]" />
          <span className="text-[var(--charcoal-light)] font-[var(--font-outfit)] tracking-wide">
            The celebration begins
          </span>
          <span className="w-8 h-px bg-[var(--purple-soft)]" />
        </motion.div>
      </motion.div>
    )
  }

  if (!timeLeft) return null

  const timeUnits = [
    { label: "Days", value: timeLeft.days },
    { label: "Hours", value: timeLeft.hours },
    { label: "Minutes", value: timeLeft.minutes },
    { label: "Seconds", value: timeLeft.seconds },
  ]

  return (
    <div className="py-8">
      <motion.p
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center text-sm tracking-[0.2em] uppercase text-[var(--charcoal-light)] mb-6 font-[var(--font-outfit)]"
      >
        Counting down to May 16th
      </motion.p>
      
      <div className="flex items-center justify-center gap-2 sm:gap-3 md:gap-6">
        {timeUnits.map((unit, index) => (
          <motion.div
            key={unit.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="text-center"
          >
            <div className="relative">
              <motion.div
                key={unit.value}
                initial={{ opacity: 0.5, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="w-14 h-14 sm:w-16 sm:h-16 md:w-20 md:h-20 flex items-center justify-center bg-white rounded-lg shadow-sm border border-[var(--border)]"
              >
                <span className="text-xl sm:text-2xl md:text-3xl font-[var(--font-syne)] font-bold text-[var(--charcoal)]">
                  {String(unit.value).padStart(2, '0')}
                </span>
              </motion.div>
              {/* Purple accent dot */}
              <div className="absolute -top-1 -right-1 w-2 h-2 bg-[var(--purple-soft)] rounded-full" />
            </div>
            <p className="mt-2 text-[10px] sm:text-xs tracking-wider uppercase text-[var(--muted-foreground)] font-[var(--font-outfit)]">
              {unit.label}
            </p>
          </motion.div>
        ))}
      </div>
    </div>
  )
}
