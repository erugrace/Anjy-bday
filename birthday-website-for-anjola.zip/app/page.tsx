"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { ParticleBackground } from "@/components/particle-background"
import { AudioPlayer } from "@/components/audio-player"
import { AgeGame } from "@/components/age-game"
import { HeroSection } from "@/components/hero-section"
import { PhotoGallery } from "@/components/photo-gallery"
import { MessageCards } from "@/components/message-cards"
import { BookGifts } from "@/components/book-gifts"
import { Footer } from "@/components/footer"

export default function BirthdayPage() {
  const [gameComplete, setGameComplete] = useState(false)

  return (
    <main className="relative min-h-screen overflow-x-hidden">
      {/* Particle background - always visible */}
      <ParticleBackground />

      {/* Audio player - shows on game page */}
      {!gameComplete && (
        <AudioPlayer src="/audio/birthday-song.mp3" autoPlay />
      )}

      <AnimatePresence mode="wait">
        {!gameComplete ? (
          /* Page 1: Age Guessing Game */
          <motion.div
            key="game"
            exit={{ opacity: 0, scale: 1.1 }}
            transition={{ duration: 0.5 }}
          >
            <AgeGame onComplete={() => setGameComplete(true)} />
          </motion.div>
        ) : (
          /* Page 2: Main Birthday Experience */
          <motion.div
            key="experience"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8 }}
          >
            <HeroSection />
            <PhotoGallery />
            <MessageCards />
            <BookGifts />
            <Footer />
          </motion.div>
        )}
      </AnimatePresence>
    </main>
  )
}
